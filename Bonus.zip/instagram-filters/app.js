var fileNameToFilter = "image.png";
var scaleFactor = 1.0;

function calculateScaleFactore(width, height) {
    var scaleFactorHeight = 1.0;
    var scaleFactorWidth = 1.0;
    var browserHeight = 600;
    var browserWidth = 700;
    if (browserHeight < height || browserWidth < width) {
        if (browserHeight < height) {
            scaleFactorHeight = parseFloat((browserHeight / height).toFixed(2));
        }
        if (browserWidth < width) {
            scaleFactorWidth = parseFloat((browserWidth / width).toFixed(2));
        }
        if (scaleFactorHeight < scaleFactorWidth)
            scaleFactor = parseFloat(scaleFactorHeight);
        else
            scaleFactor = parseFloat(scaleFactorWidth);
    } else {
        // We can zoom.
        if (browserHeight > height) {
            scaleFactorHeight = parseFloat((browserHeight / height).toFixed(2));
        }
        if (browserWidth > width) {
            scaleFactorWidth = parseFloat((browserWidth / width).toFixed(2));
        }
        if (scaleFactorHeight < scaleFactorWidth)
            scaleFactor = scaleFactorHeight;
        else
            scaleFactor = scaleFactorWidth;
    }
    return scaleFactor;
}

function dataURIToBlob(dataURI) {
    var binStr = atob(dataURI.split(',')[1]),
        len = binStr.length,
        arr = new Uint8Array(len);
    for (var i = 0; i < len; i++) {
        arr[i] = binStr.charCodeAt(i);
    }
    return new Blob([arr]);
}

function closeDownloadModalPopup() {
    $("#download-modal").css("display", 'none').css("visibility", "hidden").css("opacity", "0.0");
}

function downloadFilteredImage() {
    $("#download-modal").css("visibility", "visible").css("opacity", "1.0").css("display", "block");

    var url = document.getElementById('background-container').src.replace(/^data:image\/[^;]+/, 'data:application/octet-stream');
    if (document.getElementById('background-container').src.startsWith('http'))
        alert("Upload an image first");
    else {
        if (window.navigator.msSaveOrOpenBlob) // IE10+
            window.navigator.msSaveOrOpenBlob(dataURIToBlob(url), fileNameToFilter);
        else {
            var a = document.createElement("a");
            a.href = URL.createObjectURL(dataURIToBlob(url));
            a.download = fileNameToFilter;
            a.click();

            a.onclick = function() {
                // ..and to wait a frame
                requestAnimationFrame(function() {
                    URL.revokeObjectURL(a.href);
                });
                a.removeAttribute('href')
            };

            a.remove();
        }
    }
}
(function() {
    /* DOM */

    var upload = document.querySelector('input[type=file]');
    var errorcaption = document.querySelector('.error');




    /* Page and image setup */
    var imageToFilterDOM = document.getElementById('background-container');
    var loaderFilter = document.getElementById('loader-filter');
    var currentImageToFilter = '';
    var compressedImageToFilter = new Image();
    var filterName = ['normal', 'clarendon', 'gingham', 'moon', 'lark', 'reyes', 'juno', 'slumber', 'crema', 'ludwig', 'aden', 'perpetua', 'amaro', 'mayfair', 'rise', 'hudson', 'valencia', 'xpro2', 'sierra', 'willow', 'lofi', 'inkwell', 'hefe', 'nashville', 'stinson', 'vesper', 'earlybird', 'brannan', 'sutro', 'toaster', 'walden', '1977', 'kelvin', 'maven', 'ginza', 'skyline', 'dogpatch', 'brooklyn', 'helena', 'ashby', 'charmes'];

    function initFiltersEffect() {
        if (compressedImageToFilter.src != '') {
            $("#filterButtons").html("");
            for (var i = 0; i < filterName.length; i++) {

                $("#filterButtons").append("<div id='" + filterName[i] + "' class='filter " + filterName[i] + "'><div class='filter-tag' ><img id='filter-tag-" + filterName[i] + "' src='' style='position:relative;max-width:72px;max-height:52px;min-width:100%;min-height:52px;border-radius: 8px;'/></div><label style='font-size:14px;font-family:\"QuickSand\";text-transform:capitalize;' class='label' >" + filterName[i] + "</label></div>");
                var f = filterous.importImage(compressedImageToFilter, null)
                    .applyInstaFilter(filterName[i])
                    .renderHtml(document.getElementById("filter-tag-" + filterName[i]));
            }
        }
    }

    function showFilterLoader(loaderFilter) {
        loaderFilter.removeAttribute('hidden');
    }

    function hideFilterLoader(loaderFilter) {
        loaderFilter.setAttribute('hidden', 'hidden');
    }

    document.getElementById('filterButtons').addEventListener('click', prepFilterEffect, false);

    function prepFilterEffect(e) {
        console.log($(e.target).parents(".filter").length);
        if ($(e.target).parents(".filter").length != 0) {
            showFilterLoader(loaderFilter);

            // TODO get Filter Button from DOMTree...
            var filterButton = getFilterButton(e.target);
            if (!filterButton) return;

            var promise = new Promise(function(resolve) {
                setTimeout(function() {
                    var f = filterous.importImage(currentImageToFilter, null)
                        .applyInstaFilter(filterButton.id)
                        .renderHtml(imageToFilterDOM);
                    resolve(f);
                }, 1);
            });

            promise.then(function() {
                hideFilterLoader(loaderFilter);
            });
        }
    }

    function getFilterButton(target) {
        var button;
        if (target.classList.contains('filter')) {
            button = target;
        } else if (target.parentNode.classList.contains('filter')) {
            button = target.parentNode;
        } else if (target.parentNode.parentNode.classList.contains('filter')) {
            button = target.parentNode.parentNode;
        }
        return button;
    }










    $('#close-download').click(function() {
        closeDownloadModalPopup();
    });
    upload.addEventListener('change', function(e) {
        if (event.target.files && event.target.files[0]) {
            loadImageFromDisk(event.target.files[0]);
        }
    }, false);

    function setImage(imageName) {
        willScale = false;
        currentImageToFilter = new Image();
        currentImageToFilter.src = photos[imageName].url;
        imageToFilterDOM.src = photos[imageName].url;
    }

    var photos = {
        white: {
            url: 'images/model.jpeg'
        }
    };
    setImage('white');
    //$("#photoFrame").css("left", ($(document).width()/2-250) + "px");
    $("#overlay-white").css("display", "none");

    currentImageToFilter.type = 'image/jpeg'
    loadImageFromURL("model.jpeg", 'images/model.jpeg');


    function loadImageFromURL(imgName, targetResult) {
        currentImageToFilter = new Image();
        fileNameToFilter = imgName;
        imageToFilterDOM.src = targetResult;
        currentImageToFilter.onload = function() {
            scaleFactor = calculateScaleFactore(currentImageToFilter.width, currentImageToFilter.height);

            //    $("#background-container").css("width", currentImageToFilter.width + "px");
            //    $("#background-container").css("height",  currentImageToFilter.height +"px");
            //    document.getElementById("photoFrame").style.transform = "scale(" + scaleFactor + ")";
            // $("#photoFrame").css("left", ($(document).width()/2-350) + "px");

            // Image compression for thumbnails.

            const canvaFilter = document.createElement('canvas');
            canvaFilter.width = 80;
            const newHeight = canvaFilter.width * (currentImageToFilter.height / currentImageToFilter.width);
            canvaFilter.height = newHeight;
            const ctx = canvaFilter.getContext('2d');
            ctx.drawImage(currentImageToFilter, 0, 0, 100, newHeight);
            compressedImageToFilter.src = canvaFilter.toDataURL('image/png');
            // Image compression for thumbnails.



            compressedImageToFilter.onload = function() {

                // Actions after compression.
                initFiltersEffect();
                $("#download-button").css("display", "block");
                $("#filters-nav").css("display", "block");
            };

        }
        currentImageToFilter.src = targetResult;
        document.getElementById("upload-background").value = "";
    }
    var errorText = document.getElementById("error-text");

    function loadImageFromDisk(file) {
        if (!file.type.match(/image.*/)) {
            errorText.textContent = "The dropped file is not an image";
            return;
        }
        errorText.textContent = "";
        var reader = new FileReader();
        reader.onload = function(e) {
            loadImageFromURL(file.name, e.target.result);
        };

        reader.readAsDataURL(file);
    }











    function handleDragOver(evt) {
        evt.stopPropagation();
        evt.preventDefault();
        evt.dataTransfer.dropEffect = 'copy'; // Explicitly show this is a copy.
    }

    function handleFileSelect(evt) {
        evt.stopPropagation();
        evt.preventDefault();
        loadImageFromDisk(evt.dataTransfer.files[0]);
    }



    var dropZone = document.getElementById('drop_zone');
    dropZone.addEventListener('dragover', handleDragOver, false);
    dropZone.addEventListener('dragenter', function() {
        document.getElementById('drop_zone').classList.add("dragenter");
    }, false);
    dropZone.addEventListener('dragleave', function() {
        document.getElementById('drop_zone').classList.remove("dragenter");
    }, false);
    dropZone.addEventListener('dragend', function() {
        document.getElementById('drop_zone').classList.remove("dragover");
    }, false);

    dropZone.addEventListener('drop', handleFileSelect, false);


})();